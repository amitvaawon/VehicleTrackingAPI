﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Text;


namespace Vehicle.DAL.Data.Repository
{
    public class VehicleData :IVehicleData
    {
        
        //private readonly IMongoCollection<User> _users;
        //private readonly IMongoCollection<VehicleDevice> _vehicleDevice;
        //private readonly IMongoCollection<VehiclePosition> _vehiclePosition;
        public async Task<long> GetByRegAsync(Vehicle.DAL.Data.Models.Vehicle vehicle, string regNo)
        {
            return await vehicle.Find<Vehicle>(s => s.VehicleRegisterNumber == regNo).CountDocumentsAsync();
        }
    }
}
