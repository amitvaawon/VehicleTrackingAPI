﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle.DAL.Data.Repository
{
    public interface IVehicleData
    {
        Task<long> GetByRegAsync(string regNo);
    }
}
