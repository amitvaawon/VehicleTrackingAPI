﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;
using VehicleTrackingAPI.Services;

namespace VehicleTrackingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleController : ControllerBase
    {
        private readonly IVehicleService _vehicleService;
        public VehicleController(IVehicleService vehicleService)
        {
            _vehicleService = vehicleService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Vehicle>>> GetAll()
        {
            var objVehicle = await _vehicleService.GetAllAsync();
            return Ok(objVehicle);
        }


        /* Below are the api object format for register a vehicle
         * {
                "User": {
                    "EmailID": "amitavaawon@gmail.com"
                },
                "VehicleName": "BMW",
                "VehicleRegisterNumber": "BMW007",
                "VehicleDevice": {
                    "DeviceSerialNo": "D1000",
                    "DeviceName": "GPS DEVICE"
                }
            } 
        */
        [HttpPost]
        public async Task<IActionResult> Create(VehicleMaster vehicle)
        {
            bool vehicleDt = await _vehicleService.RegisterVehicle(vehicle);
            return Ok(vehicleDt);
        }

        /* Below are the api object format for record a vehicle position
          {
            "EmailID": "amitavaawon@gmail.com",
            "DeviceSerialNo": "D1000",
            "Latitude": 12.32,
            "Longitude": 24.42
           }
        */
        [HttpPut]
        public async Task<ActionResult> PutVehiclePosition(VehiclePositionMaster vehiclePosition)
        {
            try
            {
                bool dt = await _vehicleService.RecordVehiclePositionAsync(vehiclePosition);
                return Ok(dt);
            }
            catch (Exception ex)
            {
                return NotFound();
            }


        }


        [HttpGet("{userID}/{deviceId}")]
        public ActionResult GetVehicleCurrentPosition(string userID, string deviceId)
        {

            VehiclePosition vehicle = null;
            try
            {
                if (!string.IsNullOrEmpty(userID) && !string.IsNullOrEmpty(deviceId))
                {
                    vehicle = _vehicleService.GetCurrentVehiclePosition(userID, deviceId);
                    if (vehicle == null)
                    {
                        return NotFound();
                    }
                    return Ok(vehicle);
                }
                else
                {
                    return StatusCode(400);
                }
            }
            catch (Exception ex)
            {
                return NotFound();
            }
        }

        [HttpGet("{userID}/{deviceId}/{startDate}/{endDate}")]
        public ActionResult GetVehicleCurrentPositionRange(string userID, string deviceId, DateTime startDate, DateTime endDate)
        {

            List<VehiclePosition> ObjVehiclePosition = null;
            try
            {
                if (!string.IsNullOrEmpty(userID) && !string.IsNullOrEmpty(deviceId))
                {
                    ObjVehiclePosition = _vehicleService.GetCurrentVehiclePositionRange(userID, deviceId, startDate, endDate);
                    if (ObjVehiclePosition == null)
                    {
                        return NotFound();
                    }
                    return Ok(ObjVehiclePosition);
                }
                else
                {
                    return StatusCode(400);
                }
            }
            catch (Exception ex)
            {
                return NotFound();
            }
        }
    }
}
