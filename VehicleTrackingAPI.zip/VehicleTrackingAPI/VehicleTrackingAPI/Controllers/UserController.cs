﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;
using VehicleTrackingAPI.Services;

namespace VehicleTrackingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        public UserController(IUserService usereService)
        {
            _userService = usereService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetAll()
        {
            var user = await _userService.GetAllAsync();
            return Ok(user);
        }


        /* Below are the api object format for User Creation
         * {
                "UserName": "Amitava",
                "EmailID": "amitavaawon@gmail.com",
                "Password": "1234",  // Password will store in encrypted format
                "RoleID": "2"
            }
         */
        [HttpPost]
        public async Task<IActionResult> Create(User userDt)
        {
            var user = await _userService.CreateUserAsync(userDt);
            return Ok(user);
        }

    }

    
}
