﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;
using VehicleTrackingAPI.Services;

namespace VehicleTrackingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly IRoleService _userRoleService;
        public RoleController(IRoleService usereRoleService)
        {
            _userRoleService = usereRoleService;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<UserRole>>> GetAll()
        {
            var userRole = await _userRoleService.GetAllAsync();
            return Ok(userRole);
        }

        [HttpPost]
        public async Task<IActionResult> Create(UserRole userRoleDt)
        {
            var userRole = await _userRoleService.CreateAsync(userRoleDt);
            return Ok(userRole);
        }
    }
}
