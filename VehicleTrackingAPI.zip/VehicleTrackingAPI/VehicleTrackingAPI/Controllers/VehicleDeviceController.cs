﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;
using VehicleTrackingAPI.Services;

namespace VehicleTrackingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleDeviceController : ControllerBase
    {
        private readonly IVehicleDeviceService _vehicleDeviceService;
        public VehicleDeviceController(IVehicleDeviceService vehicleDeviceService)
        {
            _vehicleDeviceService = vehicleDeviceService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VehicleDevice>>> GetAll()
        {
            var userRole = await _vehicleDeviceService.GetAllAsync();
            return Ok(userRole);
        }
        [HttpPost]
        public async Task<IActionResult> Create(VehicleDevice vehicleDevice)
        {
            var vehicleDt = await _vehicleDeviceService.CreateAsync(vehicleDevice);
            return Ok(vehicleDt);
        }
    }
}
