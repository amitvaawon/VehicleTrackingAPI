﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;

namespace VehicleTrackingAPI.Repository
{
    public interface IRoleRepository
    {
        Task<List<UserRole>> GetAllAsync();
        Task<bool> CreateRoleAsync(UserRole userRole);
    }
}
