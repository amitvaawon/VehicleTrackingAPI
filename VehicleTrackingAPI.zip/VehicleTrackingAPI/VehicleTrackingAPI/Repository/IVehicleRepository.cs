﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;

namespace VehicleTrackingAPI.Repository
{
    public interface IVehicleRepository
    {
        Task<List<Vehicle>> GetAllAsync();
        Task<Vehicle> GetByIdAsync(string id);
        Task<long> GetByRegAsync(string regNo);

        Task<User> GetByEmailAsync(string EmailID);

        Task<bool> RegisterVehicle(Vehicle objVehicle);

        Task<bool> RegisterDevice(VehicleDevice objDevice);

        VehiclePosition CheckUserWithVehicleDevice(string EmailID, string DeviceSerialNo);

        Task<bool> RecordVehiclePosition(VehiclePosition objVehiclePosition);

        VehiclePosition GetCurrentVehiclePosition(string userID, string deviceId);

        List<VehiclePosition> GetCurrentVehiclePositionRange(string userID, string deviceId, DateTime startDate, DateTime endDate);
    }
}
