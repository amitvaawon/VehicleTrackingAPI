﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;

namespace VehicleTrackingAPI.Repository
{
    public class RoleRepository :IRoleRepository
    {
        private readonly IMongoCollection<UserRole> _usersRole;

        public RoleRepository(IVehicleTrackingDatabaseSetting settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _usersRole = database.GetCollection<UserRole>(settings.UserRoleCollectionName);
        }

        public async Task<List<UserRole>> GetAllAsync()
        {
            return await _usersRole.Find(s => true).ToListAsync();
        }
        public async Task<bool> CreateRoleAsync(UserRole userRole)
        {
            bool ret;
            try
            {
                await _usersRole.InsertOneAsync(userRole);
                ret = true;
            }
            catch (Exception)
            {
                ret = false;
            }
            return ret;
        }
    }
}
