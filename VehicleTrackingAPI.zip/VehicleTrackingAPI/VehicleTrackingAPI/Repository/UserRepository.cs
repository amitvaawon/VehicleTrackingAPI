﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;

namespace VehicleTrackingAPI.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly IMongoCollection<User> _users;

        public UserRepository(IVehicleTrackingDatabaseSetting settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _users = database.GetCollection<User>(settings.UserCollectionName);
        }

        public async Task<User> GetByEmailIdAsync(string email)
        {
            return await _users.Find<User>(s => s.EmailID == email).FirstOrDefaultAsync();
        }

        public async Task<List<User>> GetAllAsync()
        {
            return await _users.Find(s => true).ToListAsync();
        }

        public async Task<bool> CreateUserAsync(User user)
        {
            bool ret = false;
            try
            {
                if (user != null)
                {
                    await _users.InsertOneAsync(user);
                    ret = true;
                }
            }
            catch (Exception ex)
            {
                ret = false;
            }
            return ret;
        }

    }
}
