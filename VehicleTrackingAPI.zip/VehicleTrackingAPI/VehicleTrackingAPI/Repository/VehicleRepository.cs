﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;

namespace VehicleTrackingAPI.Repository
{
    public class VehicleRepository : IVehicleRepository
    {
        private readonly IMongoCollection<Vehicle> _vehicles;
        private readonly IMongoCollection<User> _users;
        private readonly IMongoCollection<VehicleDevice> _vehicleDevice;
        private readonly IMongoCollection<VehiclePosition> _vehiclePosition;

        public VehicleRepository(IVehicleTrackingDatabaseSetting settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);

            _vehicles = database.GetCollection<Vehicle>(settings.VehicleCollectionName);
            _users = database.GetCollection<User>(settings.UserCollectionName);
            _vehicleDevice = database.GetCollection<VehicleDevice>(settings.VehicleDeviceCollectionName);
            _vehiclePosition = database.GetCollection<VehiclePosition>(settings.VehiclePositionCollectionName);
        }

        public async Task<List<Vehicle>> GetAllAsync()
        {
            return await _vehicles.Find(s => true).ToListAsync();
        }

        public async Task<Vehicle> GetByIdAsync(string id)
        {
            return await _vehicles.Find<Vehicle>(s => s.VehicleID == id).FirstOrDefaultAsync();
        }

        public async Task<long> GetByRegAsync(string regNo)
        {
            return await _vehicles.Find<Vehicle>(s => s.VehicleRegisterNumber == regNo).CountDocumentsAsync();
        }

        public async Task<User> GetByEmailAsync(string EmailID)
        {
            return await _users.Find<User>(s => s.EmailID == EmailID).FirstOrDefaultAsync();
        }

        public async Task<bool> RegisterVehicle(Vehicle objVehicle)
        {
            bool ret;
            try
            {
                await _vehicles.InsertOneAsync(objVehicle);
                ret = true;
            }
            catch (Exception)
            {

                ret = false;
            }
            return ret;
        }

        public async Task<bool> RegisterDevice(VehicleDevice objDevice)
        {
            bool ret;
            try
            {
                await _vehicleDevice.InsertOneAsync(objDevice);
                ret = true;
            }
            catch (Exception)
            {

                ret = false;
            }
            return ret;
        }

        public VehiclePosition CheckUserWithVehicleDevice(string EmailID, string DeviceSerialNo)
        {
            VehiclePosition objVehiclePosition = new VehiclePosition();
            try
            {
                objVehiclePosition = (from p in _vehicles.AsQueryable()
                       join o in _vehicleDevice.AsQueryable() on p.VehicleID equals o.VehicleID
                       join u in _users.AsQueryable() on p.UserID equals u.UserID
                       where u.EmailID == EmailID & o.DeviceSerialNo == DeviceSerialNo
                       select new VehiclePosition
                       {
                           UserID = p.UserID,
                           DeviceID = o.DeviceID
                       }).FirstOrDefault();

                return objVehiclePosition;
            }
            catch (Exception)
            {
                return objVehiclePosition;
            }
        }

        public async Task<bool> RecordVehiclePosition(VehiclePosition objVehiclePosition)
        {
            bool ret;
            try
            {
                await _vehiclePosition.InsertOneAsync(objVehiclePosition);
                ret = true;
            }
            catch (Exception)
            {

                ret = false;
            }
            return ret;
        }


        public VehiclePosition GetCurrentVehiclePosition(string userID, string deviceId)
        {

            VehiclePosition objVehiclePosition = new VehiclePosition();
            try
            {
                objVehiclePosition = (from p in _vehicles.AsQueryable()
                       join o in _vehicleDevice.AsQueryable() on p.VehicleID equals o.VehicleID
                       join v in _vehiclePosition.AsQueryable() on o.DeviceID equals v.DeviceID
                       join u in _users.AsQueryable() on p.UserID equals u.UserID
                       
                       where u.UserID == userID && o.DeviceID == deviceId
                       select new VehiclePosition
                       {
                           UserID = p.UserID,
                           DeviceID = o.DeviceID,
                           Latitude=v.Latitude,
                           Longitude=v.Longitude,
                           UpdateLocationTimeStamp=v.UpdateLocationTimeStamp
                       }).OrderByDescending(t=>t.UpdateLocationTimeStamp).FirstOrDefault();

                return objVehiclePosition;
            }
            catch (Exception)
            {
                return objVehiclePosition;
            }
        }


        public List<VehiclePosition> GetCurrentVehiclePositionRange(string userID, string deviceId, DateTime startDate, DateTime endDate)
        {

            List<VehiclePosition> objVehiclePosition = new List<VehiclePosition>();
            try
            {
                objVehiclePosition = (from p in _vehicles.AsQueryable()
                                      join o in _vehicleDevice.AsQueryable() on p.VehicleID equals o.VehicleID
                                      join v in _vehiclePosition.AsQueryable() on o.DeviceID equals v.DeviceID
                                      join u in _users.AsQueryable() on p.UserID equals u.UserID

                                      where u.UserID == userID && o.DeviceID == deviceId && v.UpdateLocationTimeStamp >= startDate&& v.UpdateLocationTimeStamp <= endDate
                                      select new VehiclePosition
                                      {
                                          UserID = p.UserID,
                                          DeviceID = o.DeviceID,
                                          Latitude = v.Latitude,
                                          Longitude = v.Longitude,
                                          UpdateLocationTimeStamp = v.UpdateLocationTimeStamp
                                      }).OrderByDescending(t => t.UpdateLocationTimeStamp).ToList();

                return objVehiclePosition;
            }
            catch (Exception)
            {
                return objVehiclePosition;
            }
        }

    }
}
