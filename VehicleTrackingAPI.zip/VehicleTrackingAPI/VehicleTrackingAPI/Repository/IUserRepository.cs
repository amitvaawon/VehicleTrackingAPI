﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;

namespace VehicleTrackingAPI.Repository
{
    public interface IUserRepository
    {
        Task<User> GetByEmailIdAsync(string email);
        Task<List<User>> GetAllAsync();
        Task<bool> CreateUserAsync(User user);
    }
}
