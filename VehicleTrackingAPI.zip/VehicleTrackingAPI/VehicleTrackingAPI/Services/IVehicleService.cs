﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;

namespace VehicleTrackingAPI.Services
{
    public interface IVehicleService
    {
        Task<List<Vehicle>> GetAllAsync();
        Task<bool> RegisterVehicle(VehicleMaster vehicle);

        Task<bool> RecordVehiclePositionAsync(VehiclePositionMaster vehiclePosition);

        VehiclePosition GetCurrentVehiclePosition(string userID, string deviceID);

        List<VehiclePosition> GetCurrentVehiclePositionRange(string userID, string deviceID, DateTime startDate, DateTime endDate);
    }
}
