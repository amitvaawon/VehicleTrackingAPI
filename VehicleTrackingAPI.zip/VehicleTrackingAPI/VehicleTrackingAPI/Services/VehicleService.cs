﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;
using VehicleTrackingAPI.Repository;
using VehicleTrackingAPI.Utility;

namespace VehicleTrackingAPI.Services
{
    public class VehicleService : IVehicleService
    {
        private readonly IVehicleRepository _vehicleRepository;
        public VehicleService(IVehicleRepository vehicleRepository)
        {
            _vehicleRepository = vehicleRepository;
        }
        public async Task<List<Vehicle>> GetAllAsync()
        {
            return await _vehicleRepository.GetAllAsync();
        }
        public async Task<Vehicle> GetByIdAsync(string id)
        {
            return await _vehicleRepository.GetByIdAsync(id);
        }
        public async Task<long> GetByRegAsync(string regNo)
        {
            return await _vehicleRepository.GetByRegAsync(regNo);
        }
        public async Task<bool> RegisterVehicle(VehicleMaster vehiclesMaster)
        {
            bool res = true;
            try
            {
                if (vehiclesMaster != null)
                {
                    var ret = await _vehicleRepository.GetByEmailAsync(vehiclesMaster.User.EmailID);
                    if (ret != null)
                    {
                        var veh_ret = await _vehicleRepository.GetByRegAsync(vehiclesMaster.VehicleRegisterNumber);
                        if (veh_ret == 0)
                        {
                            var objVehicle = new Vehicle()
                            {
                                UserID = ret.UserID,
                                VehicleName = vehiclesMaster.VehicleName,
                                VehicleRegisterNumber = vehiclesMaster.VehicleRegisterNumber,
                                UpdateTimeStamp = DateTime.Now,
                                VehicleID = Guid.NewGuid().ToString()
                            };
                            await _vehicleRepository.RegisterVehicle(objVehicle);

                            var objDevice = new VehicleDevice()
                            {
                                VehicleID = objVehicle.VehicleID,
                                DeviceID = Guid.NewGuid().ToString(),
                                DeviceSerialNo = vehiclesMaster.VehicleDevice.DeviceSerialNo,
                                DeviceName = vehiclesMaster.VehicleDevice.DeviceName
                            };
                            await _vehicleRepository.RegisterDevice(objDevice);

                            res = true;
                        }

                    }
                    else
                    {
                        res = false;
                    }
                }
            }
            catch (Exception ex)
            {

                res = false;
            }
            return res;
        }
        public async Task<bool> RecordVehiclePositionAsync(VehiclePositionMaster vehiclePosition)
        {
            bool ret = false;
            VehiclePosition vehiclePositionObj = new VehiclePosition();
            vehiclePositionObj = _vehicleRepository.CheckUserWithVehicleDevice(vehiclePosition.EmailID, vehiclePosition.DeviceSerialNo);
            if (vehiclePositionObj != null)
            {
                if (vehiclePosition != null)
                {
                    var objVehiclePosition = new VehiclePosition()
                    {
                        UserID = vehiclePositionObj.UserID,
                        DeviceID = vehiclePositionObj.DeviceID,
                        Latitude = vehiclePosition.Latitude,
                        Longitude = vehiclePosition.Longitude,
                        UpdateLocationTimeStamp = DateTime.Now
                    };
                   ret= await _vehicleRepository.RecordVehiclePosition(objVehiclePosition);
                }
            }
            return ret;
        }

        public VehiclePosition GetCurrentVehiclePosition(string userID, string deviceID)
        {
            VehiclePosition result = null;
            try
            {
                result = _vehicleRepository.GetCurrentVehiclePosition(userID, deviceID);
            }
            catch (Exception)
            {
                return null;
            }

            return result;
        }

        public List<VehiclePosition> GetCurrentVehiclePositionRange(string userID, string deviceID, DateTime startDate, DateTime endDate)
        {
            List<VehiclePosition> result = null;
            try
            {
                result = _vehicleRepository.GetCurrentVehiclePositionRange(userID, deviceID, startDate, endDate);
            }
            catch (Exception)
            {
                return null;
            }

            return result;
        }
    }
}
