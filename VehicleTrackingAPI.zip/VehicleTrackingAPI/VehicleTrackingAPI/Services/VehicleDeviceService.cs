﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;

namespace VehicleTrackingAPI.Services
{
    public class VehicleDeviceService :IVehicleDeviceService
    {
        private readonly IMongoCollection<VehicleDevice> _vehicleDevice;
        public VehicleDeviceService(IVehicleTrackingDatabaseSetting settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);

            _vehicleDevice = database.GetCollection<VehicleDevice>(settings.VehicleDeviceCollectionName);
        }

        public async Task<List<VehicleDevice>> GetAllAsync()
        {
            return await _vehicleDevice.Find(s => true).ToListAsync();
        }
        public async Task<VehicleDevice> GetByIdAsync(string id)
        {
            return await _vehicleDevice.Find<VehicleDevice>(s => s.DeviceID == id).FirstOrDefaultAsync();
        }
        public async Task<bool> CreateAsync(VehicleDevice vehicleDevice)
        {
            await _vehicleDevice.InsertOneAsync(vehicleDevice);
            return true;
        }
        public async Task UpdateAsync(string id, VehicleDevice vehicleDevice)
        {
            await _vehicleDevice.ReplaceOneAsync(s => s.DeviceID == id, vehicleDevice);
        }
        public async Task DeleteAsync(string id)
        {
            await _vehicleDevice.DeleteOneAsync(s => s.DeviceID == id);
        }
    }
}
