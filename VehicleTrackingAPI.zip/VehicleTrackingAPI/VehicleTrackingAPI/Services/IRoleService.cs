﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;

namespace VehicleTrackingAPI.Services
{
    public interface IRoleService
    {
        Task<List<UserRole>> GetAllAsync();
        Task<bool> CreateAsync(UserRole userRole);
    }
}
