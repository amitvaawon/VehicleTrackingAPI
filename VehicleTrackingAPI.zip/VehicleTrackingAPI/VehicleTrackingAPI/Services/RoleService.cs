﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;
using VehicleTrackingAPI.Repository;

namespace VehicleTrackingAPI.Services
{
    public class RoleService :IRoleService
    {
        private readonly IRoleRepository _roleRepository;
        public RoleService(IRoleRepository roleRepository)
        {
            _roleRepository = roleRepository;
        }

        public async Task<List<UserRole>> GetAllAsync()
        {
            return await _roleRepository.GetAllAsync();
        }
    
        public async Task<bool> CreateAsync(UserRole userRole)
        {
            bool result = false;
            try
            {
                if (userRole != null)
                {
                    await _roleRepository.CreateRoleAsync(userRole);
                }
            }
            catch (Exception)
            {
                result = false;
            }

            return result;
        }

    }
}
