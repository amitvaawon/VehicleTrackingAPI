﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleTrackingAPI.Models;
using VehicleTrackingAPI.Repository;
using VehicleTrackingAPI.Utility;

namespace VehicleTrackingAPI.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<List<User>> GetAllAsync()
        {
            return await _userRepository.GetAllAsync();
        }
        public async Task<bool> CreateUserAsync(User user)
        {
            bool result = false;
            try
            {
                if (user != null)
                {
                    var ret = await _userRepository.GetByEmailIdAsync(user.EmailID);
                    if (ret == null)
                    {
                        user.UserID = Guid.NewGuid().ToString();
                        user.Password = PasswordEncryption.HashSHA1(user.Password);
                        await _userRepository.CreateUserAsync(user);
                        result = true;
                    }
                }
            }
            catch (Exception)
            {
                result = false;
            }

            return result;
        }
        
    }
}
