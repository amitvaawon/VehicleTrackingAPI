﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleTrackingAPI.Models
{
    public class VehicleTrackingDatabaseSetting : IVehicleTrackingDatabaseSetting
    {
        public string UserCollectionName { get; set; }

        public string UserRoleCollectionName { get; set; }

        public string VehicleCollectionName { get; set; }

        public string VehicleDeviceCollectionName { get; set; }
        public string VehiclePositionCollectionName { get; set; }
        public string ConnectionString { get; set; }
        public string DatabaseName { get; set; }
    }

    public interface IVehicleTrackingDatabaseSetting
    {
        string UserCollectionName { get; set; }
        string UserRoleCollectionName { get; set; }
        string VehicleCollectionName { get; set; }
        string VehicleDeviceCollectionName { get; set; }
        string VehiclePositionCollectionName { get; set; }
        string ConnectionString { get; set; }
        string DatabaseName { get; set; }
    }
}
