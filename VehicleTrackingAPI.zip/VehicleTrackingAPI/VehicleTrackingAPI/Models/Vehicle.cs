﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleTrackingAPI.Models
{
    [BsonIgnoreExtraElements]
    public class Vehicle
    {
        public string VehicleID { get; set; }
        public string VehicleName { get; set; }
        public string VehicleRegisterNumber { get; set; }
        public DateTime UpdateTimeStamp { get; set; }
        public string UserID { get; set; }

    }


    public class VehicleMaster
    {
        public string VehicleID { get; set; }
        public string VehicleName { get; set; }
        public string VehicleRegisterNumber { get; set; }
        public DateTime UpdateTimeStamp { get; set; }

        public virtual User User { get; set; }
        public virtual UserRole UserRole { get; set; }
        public virtual VehicleDevice VehicleDevice { get; set; }

    }
}
