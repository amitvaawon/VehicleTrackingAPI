﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace VehicleTrackingAPI.Models
{
    public class UserRole
    {
        public string RoleID { get; set; }
        public string RoleName { get; set; }
    }
}
