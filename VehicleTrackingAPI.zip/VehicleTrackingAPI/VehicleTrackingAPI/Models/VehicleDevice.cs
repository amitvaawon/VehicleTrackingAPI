﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleTrackingAPI.Models
{
    [BsonIgnoreExtraElements]
    public class VehicleDevice
    {
        public string DeviceID { get; set; }

        public string DeviceSerialNo { get; set; }
        public string DeviceName { get; set; }

        public string VehicleID { get; set; }
    }
}
