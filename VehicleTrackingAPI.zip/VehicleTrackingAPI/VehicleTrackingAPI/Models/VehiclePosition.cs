﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleTrackingAPI.Models
{
    [BsonIgnoreExtraElements]
    public class VehiclePosition
    {
        public string UserID { get; set; }
        public string DeviceID { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public DateTime UpdateLocationTimeStamp { get; set; }
    }


    public class VehiclePositionMaster
    {
        public string EmailID { get; set; }
        public string DeviceSerialNo { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
    }
}
